#include<linux/init.h>
#include<linux/module.h>
#include<linux/printk.h>

#include<linux/fs.h>

struct file_operations fops = {
	.open = my_open,
	.read = my_read,
	.write = my_write,
	.release = my_release,

}


MODULE_AUTHOR("something");
MODULE_LICENCE("GPL");
MODULE_DESCRIPTION("Ioana rullz module\n");

static int __init my_init(void)
{
	printk(KERN_DEBUG "Ioana rulz");

	register_chrdev(0, "Drv", &fops);

	return 0;
}

static void __exit my_exit(void)
{
	printk(KERN_DEBUG "Byee, cruel world\n");
	
	unregister_chrdev(0, "Drv");

}

module_init(my_init);
module_exit(my_exit);
