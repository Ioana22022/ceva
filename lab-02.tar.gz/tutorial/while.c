int main() {
    int x = 1000, i = 42;
    while (--i > 0) {
        x--;
    }
    return 0;
}
