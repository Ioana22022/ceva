int main() {
    int x = 1000;
    for (int i = 1; i < 10; i++) {
        x++;
    }
    return 0;
}
